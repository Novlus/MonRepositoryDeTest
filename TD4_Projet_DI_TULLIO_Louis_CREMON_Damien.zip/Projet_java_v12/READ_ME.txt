Bonjour Monsieur

Pour information, je vous envoie le td4 avec une petite partie du projet. (Nous avions besoin de commencer le projet pour mieux comprendre
ce que nous devrions faire pour le TD4)

Controller.java est le controller du Gestionnaire de revue pour le TD4.
Pour executer le programme il faudra vous rendre sur le main dans le package application.

