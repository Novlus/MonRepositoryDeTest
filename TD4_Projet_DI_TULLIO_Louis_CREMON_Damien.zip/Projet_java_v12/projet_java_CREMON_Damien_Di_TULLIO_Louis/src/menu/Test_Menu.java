package menu;

public class Test_Menu 
{
	public static void main(String [] args) 
	{
		Menu Menu1 = new Menu();
		Menu1.Menu_principal();
	}
}
