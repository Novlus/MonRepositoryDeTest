package dao;

import java.util.List;

import modele.metier.Periodicite;

public interface PeriodiciteDAO extends DAO<Periodicite>
{
	public abstract Periodicite getByLibelle(String libelle);
	public abstract List<Periodicite> findAll();
}
