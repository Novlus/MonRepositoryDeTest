package application;

import factory.DAOFactory;
import factory.Persistance;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import modele.metier.Periodicite;

public class Controller_Table_Periodicite implements ChangeListener<Periodicite>
{
 @FXML
 private TableView<Periodicite> tblPeriodicite ;
 @FXML
 private Button btn_supprimer;
 
 
 
 public void initialize()
	{
	 	TableColumn <Periodicite, String> colLibelle = new TableColumn<> ("Libell�");
	 	colLibelle.setCellValueFactory(new PropertyValueFactory<Periodicite, String>("libelle"));
	 	this.tblPeriodicite.getColumns().setAll(colLibelle);
	 	this.tblPeriodicite.getItems().addAll(DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE).getPeriodiciteDAO().findAll());
	 	this.tblPeriodicite.getSelectionModel().selectedItemProperty().addListener(this);
	 	
	}
 
 public void changed(ObservableValue<? extends Periodicite> observable, Periodicite oldValue, Periodicite newValue)
 {
	 this.btn_supprimer.setDisable(newValue == null);
 }
}


