package application;
	
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import modele.metier.Revue;


public class Main extends Application {
	protected Stage primaryStage = new Stage();
	@Override
	public void start(Stage primaryStage) 
		{
		try {
			FXMLLoader loader = new FXMLLoader() ;
			Parent root = loader.load(getClass().getResource("Vue.fxml"));
			Scene scene = new Scene(root);
			loader.setController("Main.java");
			primaryStage.setScene(scene);
			primaryStage.setTitle("Gestion des persistences");
			primaryStage.setMaxWidth(700);
			primaryStage.setMinWidth(700);
			primaryStage.setMaxHeight(500);
			primaryStage.setMinHeight(500);
			primaryStage.show();
			this.primaryStage = primaryStage ;
		} catch(Exception e) {
			e.printStackTrace();
		}
		}

		 

	
	public static void main(String[] args) {
		launch(args);
	}
}
