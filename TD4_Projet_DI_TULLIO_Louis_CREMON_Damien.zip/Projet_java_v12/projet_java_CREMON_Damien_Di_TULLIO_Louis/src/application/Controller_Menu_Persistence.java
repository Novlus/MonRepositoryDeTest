package application;

import factory.DAOFactory;
import factory.Persistance;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Controller_Menu_Persistence extends Main
{
	@FXML private Button btn_mysql;
	@FXML private Button btn_liste_memoire;
	@FXML private Button btn_fermer;
	@FXML private AnchorPane id_anchor;
	protected DAOFactory daos = null;
	private boolean continuer2 = false;
	public void choix_liste_memoire()
	{
		
		this.daos = DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE);
		System.out.println("Choix persistence Liste Memoire");
			try {
				Parent root = FXMLLoader.load(getClass().getResource("Metier.fxml"));
				FXMLLoader loader = new FXMLLoader() ;
				Scene scene = new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.setTitle("Gestion des metiers");
				primaryStage.setMaxWidth(700);
				primaryStage.setMinWidth(700);
				primaryStage.setMaxHeight(500);
				primaryStage.setMinHeight(500);
				primaryStage.show();
				id_anchor.disabledProperty();
				
				
			} catch(Exception e) {
				e.printStackTrace();
			}
				
		 	
		 	
		

	}
	
	public void choix_mysql()
	{
		this.daos = DAOFactory.getDAOFactory(Persistance.MYSQL);
		System.out.println("Choix persistence MySQL");
		
			try {
				Parent root = FXMLLoader.load(getClass().getResource("Metier.fxml"));
				FXMLLoader loader = new FXMLLoader() ;
				Scene scene = new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.setTitle("Gestion des metiers");
				primaryStage.setMaxWidth(700);
				primaryStage.setMinWidth(700);
				primaryStage.setMaxHeight(500);
				primaryStage.setMinHeight(500);
				primaryStage.show();
				id_anchor.disabledProperty();
				
				
			} catch(Exception e) {
				e.printStackTrace();
			}
	}
	
	
	public void choix_fermer()
	{try {
		Stage stage = (Stage) btn_fermer.getScene().getWindow();
		stage.close();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
	
}

