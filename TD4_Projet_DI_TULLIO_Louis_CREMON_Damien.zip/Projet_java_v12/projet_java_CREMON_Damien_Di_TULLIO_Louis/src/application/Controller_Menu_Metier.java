package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Controller_Menu_Metier extends Main
{
	@FXML private Button btn_Periodicite;
	@FXML private Button btn_Revue;
	@FXML private Button btn_Abonnement;
	@FXML private Button btn_Client;
	@FXML private Button btn_Fermer;
	@FXML private AnchorPane id_anchor;	
	
	public void choix_Fermer()
	{
		try {
		Stage stage = (Stage) btn_Fermer.getScene().getWindow();
		stage.close();
	
		
	} 
	catch(Exception e) {
		e.printStackTrace();
	}
}
	
	
	public void choix_Periodicite ()
	{
		try {
			Parent root = FXMLLoader.load(getClass().getResource("Table_Periodicite.fxml"));
			FXMLLoader loader = new FXMLLoader() ;
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Gestion des Periodicit�s");
			primaryStage.setMaxWidth(700);
			primaryStage.setMinWidth(700);
			primaryStage.setMaxHeight(500);
			primaryStage.setMinHeight(500);
			primaryStage.show();
			id_anchor.disabledProperty();
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void choix_Revue ()
	{
		
	}
	
	public void choix_Client ()
	{
		
	}
	
	public void choix_Abonnement ()
	{
		
	}
	
	
}
