package application;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import modele.metier.Revue;
import modele.metier.Periodicite;
import liste_memoire.ListeMemoirePeriodiciteDAO;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import factory.DAOFactory;
import factory.Persistance;
public class Controller 
{
	@FXML private Button btn_Creer;
	@FXML private TextField text_Titre;
	@FXML private TextField text_Description;
	@FXML private TextField text_Tarif;
	@FXML private ChoiceBox cbx_Periodicite;
	@FXML private Label lbl_res;
	private ObservableList<String> periodiciteList;
	

	
	public void initialize()
	{
		DAOFactory daos =DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE);
		//ObservableList<String> periodiciteList =FXCollections.observableArrayList(daos.getPeriodiciteDAO().getById(1).getLibelle(),daos.getPeriodiciteDAO().getById(2).getLibelle());
		this.periodiciteList= periodiciteList;
		this.cbx_Periodicite.setItems(FXCollections.observableArrayList(daos.getPeriodiciteDAO().findAll()));
		//cb_Periodicite.setValue(daos.getPeriodiciteDAO().getById(1).getLibelle());
		//cb_Periodicite.setItems(this.periodiciteList);
		
	}
	
	
	public void creerModele(ActionEvent event)
	{
		
		DAOFactory daos =DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE);
		String titre = text_Titre.getText();
		String description = text_Description.getText();
		float tarif = Float.parseFloat(text_Tarif.getText());
		String visuel ="Neuf";
		int Periodicite = this.cbx_Periodicite.getSelectionModel().getSelectedIndex();
		
		int periodicite = 0;
		if (Periodicite== 0)
		{
			 periodicite  = 1;
		}
		else if (Periodicite== 1)
		{
			
			periodicite = 2;
		}
		
		
		Revue r1 = new Revue(titre, description, tarif, visuel, periodicite);
		daos.getRevueDAO().create(r1);
		lbl_res.setText(r1.toString()) ;
		System.out.println(Periodicite);
		//lbl_res.setText(text_Titre.getText()+text_Description.getText()+text_Tarif.getText()+cb_Periodicite.getPromptText());
	}
	
}
