module projet_java_CREMON_Damien_Di_TULLIO_Louis {
	requires javafx.controls;
	requires javafx.fxml;
	requires junit;
	requires java.sql;
	requires javafx.base;
	opens application to javafx.graphics, javafx.fxml;
}
